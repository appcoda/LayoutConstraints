//
//  ViewController.swift
//  Constraints
//
//  Created by Gabriel Theodoropoulos on 04/12/16.
//  Copyright © 2016 Appcoda. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var containerView1: UIView!
    
    var containerView2: UIView!
    
    var containerView3: UIView!
    
    var label1: UILabel!
    
    var label2: UILabel!
    
    var button1: UIButton!
    
    var button2: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        simpleView1()
        
//        simpleView2()
        
//        complexView1()
        
//        complexView2()
        
//        vflExample()
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    func simpleView1() {
        
    }
    
    
    func simpleView2() {
        
    }
    
    
    func complexView1() {
        
    }
    
    
    func complexView2() {
        
    }
    
    
    func vflExample() {
        
    }
}

